import { useState } from "react";
import { useNavigate } from "react-router-dom";

import API from "../api/api";

import Navbar from "../components/Navbar";

import { getRole } from "../auth/auth";

export default function CreatePost() {

  const role = getRole();

  const navigate = useNavigate();

  const [title, setTitle] = useState("");

  const [content, setContent] = useState("");

  const [image, setImage] = useState(null);

  const [loading, setLoading] = useState(false);

  // AUTHOR ONLY
  if (role !== "AUTHOR") {
    return (
      <>
        <Navbar />

        <div style={styles.denied}>
          Access Denied
        </div>
      </>
    );
  }

  const createPost = async () => {

    if (!title || !content) {
      alert("Title and content required");
      return;
    }

    try {

      setLoading(true);

      const formData = new FormData();

      formData.append("title", title);

      formData.append("content", content);

      if (image) {
        formData.append("image", image);
      }

      await API.post("/posts", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      alert("Draft created");

      navigate("/drafts");

    } catch (err) {

      console.error(err);

      alert("Failed to create post");

    } finally {

      setLoading(false);
    }
  };

  return (
    <>
      <Navbar />

      <div style={styles.page}>

        <div style={styles.card}>

          <h1 style={styles.heading}>
            Create New Post
          </h1>

          {/* TITLE */}
          <input
            type="text"
            placeholder="Post title..."
            value={title}
            onChange={(e) =>
              setTitle(e.target.value)
            }
            style={styles.input}
          />

          {/* CONTENT */}
          <textarea
            placeholder="Write your post..."
            value={content}
            onChange={(e) =>
              setContent(e.target.value)
            }
            style={styles.textarea}
          />

          {/* IMAGE */}
          <input
            type="file"
            onChange={(e) =>
              setImage(e.target.files[0])
            }
            style={styles.file}
          />

          {/* BUTTON */}
          <button
            onClick={createPost}
            style={styles.button}
          >
            {loading
              ? "Creating..."
              : "Save Draft"}
          </button>

        </div>
      </div>
    </>
  );
}

const styles = {

  page: {
    background: "#0f172a",
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    padding: "30px",
  },

  card: {
    width: "100%",
    maxWidth: "700px",
    background: "#1e293b",
    padding: "30px",
    borderRadius: "16px",
    boxShadow: "0 8px 20px rgba(0,0,0,0.3)",
  },

  heading: {
    color: "white",
    marginBottom: "25px",
  },

  input: {
    width: "100%",
    padding: "14px",
    marginBottom: "20px",
    borderRadius: "10px",
    border: "none",
    outline: "none",
    fontSize: "16px",
  },

  textarea: {
    width: "100%",
    minHeight: "250px",
    padding: "14px",
    borderRadius: "10px",
    border: "none",
    outline: "none",
    resize: "vertical",
    fontSize: "16px",
    marginBottom: "20px",
  },

  file: {
    color: "white",
    marginBottom: "20px",
  },

  button: {
    width: "100%",
    padding: "14px",
    border: "none",
    borderRadius: "10px",
    background: "#22c55e",
    color: "white",
    fontSize: "16px",
    cursor: "pointer",
  },

  denied: {
    color: "white",
    background: "#0f172a",
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    fontSize: "32px",
  },
};