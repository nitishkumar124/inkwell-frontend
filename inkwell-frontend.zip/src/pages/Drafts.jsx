import { useEffect, useState } from "react";

import API from "../api/api";

import Navbar from "../components/Navbar";

import { getRole } from "../auth/auth";

export default function Drafts() {

  const role = getRole();

  const [posts, setPosts] = useState([]);

  // AUTHOR ONLY
  if (role !== "AUTHOR") {
    return (
      <>
        <Navbar />

        <div style={styles.denied}>
          Access Denied
        </div>
      </>
    );
  }

  // FETCH AUTHOR POSTS
  const fetchPosts = async () => {

    try {

      const res = await API.get("/posts/author");

      setPosts(res.data.data);

    } catch (err) {

      console.error(err);
    }
  };

  // PUBLISH
  const publishPost = async (id) => {

    try {

      await API.put(`/posts/${id}/publish`);

      fetchPosts();

    } catch (err) {

      console.error(err);
    }
  };

  useEffect(() => {

    fetchPosts();

  }, []);

  return (
    <>
      <Navbar />

      <div style={styles.page}>

        <h1 style={styles.heading}>
          My Posts
        </h1>

        <div style={styles.grid}>

          {posts.map((p) => (

            <div key={p.id} style={styles.card}>

              {/* IMAGE */}
              {p.imageUrl && (
                <img
                  src={`http://localhost:8082${p.imageUrl}`}
                  alt="post"
                  style={styles.image}
                />
              )}

              {/* TITLE */}
              <h2 style={styles.title}>
                {p.title}
              </h2>

              {/* STATUS */}
              <div style={styles.badges}>

                {p.status === "DRAFT" && (
                  <span style={styles.draft}>
                    Draft
                  </span>
                )}

                {p.status === "PUBLISHED" && (
                  <span style={styles.published}>
                    Published
                  </span>
                )}

                {p.featured && (
                  <span style={styles.featured}>
                    ⭐ Featured
                  </span>
                )}
              </div>

              {/* CONTENT PREVIEW */}
              <p style={styles.preview}>
                {p.content.length > 100
                  ? p.content.substring(0, 100) + "..."
                  : p.content}
              </p>

              {/* ACTIONS */}
              {p.status === "DRAFT" && (
                <button
                  style={styles.publishBtn}
                  onClick={() => publishPost(p.id)}
                >
                  Publish
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

const styles = {

  page: {
    background: "#0f172a",
    minHeight: "100vh",
    padding: "30px",
    color: "white",
  },

  heading: {
    marginBottom: "30px",
  },

  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))",
    gap: "25px",
  },

  card: {
    background: "#1e293b",
    borderRadius: "14px",
    overflow: "hidden",
    boxShadow: "0 6px 14px rgba(0,0,0,0.25)",
  },

  image: {
    width: "100%",
    height: "220px",
    objectFit: "cover",
  },

  title: {
    padding: "15px",
  },

  badges: {
    display: "flex",
    gap: "10px",
    padding: "0px 15px",
  },

  draft: {
    background: "#facc15",
    color: "#000",
    padding: "5px 10px",
    borderRadius: "20px",
    fontSize: "13px",
  },

  published: {
    background: "#22c55e",
    color: "white",
    padding: "5px 10px",
    borderRadius: "20px",
    fontSize: "13px",
  },

  featured: {
    background: "#38bdf8",
    color: "#000",
    padding: "5px 10px",
    borderRadius: "20px",
    fontSize: "13px",
  },

  preview: {
    padding: "15px",
    color: "#cbd5e1",
    lineHeight: "1.6",
  },

  publishBtn: {
    width: "calc(100% - 30px)",
    margin: "0px 15px 15px 15px",
    padding: "12px",
    background: "#22c55e",
    border: "none",
    borderRadius: "8px",
    color: "white",
    cursor: "pointer",
  },

  denied: {
    background: "#0f172a",
    minHeight: "100vh",
    color: "white",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    fontSize: "32px",
  },
};