import { useEffect, useState } from "react";

import API from "../api/api";

import Navbar from "../components/Navbar";

import { getRole } from "../auth/auth";

export default function AdminPanel() {

  const role = getRole();

  const [tab, setTab] = useState("users");

  const [users, setUsers] = useState([]);

  const [posts, setPosts] = useState([]);

  const [comments, setComments] = useState([]);

  // ADMIN ONLY
  if (role !== "ADMIN") {
    return (
      <>
        <Navbar />

        <div style={styles.denied}>
          Access Denied
        </div>
      </>
    );
  }

  // USERS
  const fetchUsers = async () => {

    try {

      const res =
        await API.get("/auth/admin/users");

      setUsers(res.data.data);

    } catch (err) {

      console.error(err);
    }
  };

  // POSTS
  const fetchPosts = async () => {

    try {

      const res =
        await API.get("/posts");

      setPosts(res.data.data);

    } catch (err) {

      console.error(err);
    }
  };

  // COMMENTS
  const fetchComments = async () => {

    try {

      const res =
        await API.get("/comments/pending/all");

      setComments(res.data.data);

    } catch (err) {

      console.error(err);
    }
  };

  // UPDATE ROLE
  const updateRole = async (id, role) => {

    try {

      await API.put(
        `/auth/admin/users/${id}/role?role=${role}`
      );

      fetchUsers();

    } catch (err) {

      console.error(err);
    }
  };

  // DELETE USER
  const deleteUser = async (id) => {

    try {

      await API.delete(
        `/auth/admin/users/${id}`
      );

      fetchUsers();

    } catch (err) {

      console.error(err);
    }
  };

  // FEATURE POST
  const featurePost = async (id) => {

    try {

      await API.put(
        `/posts/${id}/feature`
      );

      fetchPosts();

    } catch (err) {

      console.error(err);
    }
  };

  // DELETE POST
  const deletePost = async (id) => {

    try {

      await API.delete(`/posts/${id}`);

      fetchPosts();

    } catch (err) {

      console.error(err);
    }
  };

  // APPROVE COMMENT
  const approveComment = async (id) => {

    try {

      await API.put(
        `/comments/${id}/approve`
      );

      fetchComments();

    } catch (err) {

      console.error(err);
    }
  };

  // REJECT COMMENT
  const rejectComment = async (id) => {

    try {

      await API.put(
        `/comments/${id}/reject`
      );

      fetchComments();

    } catch (err) {

      console.error(err);
    }
  };

  useEffect(() => {

    fetchUsers();

    fetchPosts();

    fetchComments();

  }, []);

  return (
    <>
      <Navbar />

      <div style={styles.page}>

        <h1 style={styles.heading}>
          Admin Panel
        </h1>

        {/* TABS */}
        <div style={styles.tabs}>

          <button
            style={styles.tab}
            onClick={() => setTab("users")}
          >
            Users
          </button>

          <button
            style={styles.tab}
            onClick={() => setTab("posts")}
          >
            Posts
          </button>

          <button
            style={styles.tab}
            onClick={() => setTab("comments")}
          >
            Comments
          </button>
        </div>

        {/* USERS */}
        {tab === "users" && (
          <div>

            {users.map((u) => (

              <div
                key={u.id}
                style={styles.card}
              >

                <div>
                  <h3>{u.username}</h3>
                  <p>{u.email}</p>
                  <p>{u.role}</p>
                </div>

                <div style={styles.actions}>

                  <button
                    style={styles.author}
                    onClick={() =>
                      updateRole(
                        u.id,
                        "AUTHOR"
                      )
                    }
                  >
                    Make Author
                  </button>

                  <button
                    style={styles.admin}
                    onClick={() =>
                      updateRole(
                        u.id,
                        "ADMIN"
                      )
                    }
                  >
                    Make Admin
                  </button>

                  <button
                    style={styles.delete}
                    onClick={() =>
                      deleteUser(u.id)
                    }
                  >
                    Delete
                  </button>

                </div>
              </div>
            ))}
          </div>
        )}

        {/* POSTS */}
        {tab === "posts" && (
          <div>

            {posts.map((p) => (

              <div
                key={p.id}
                style={styles.card}
              >

                <div>
                  <h3>{p.title}</h3>

                  <p>
                    {p.featured
                      ? "⭐ Featured"
                      : "Normal"}
                  </p>
                </div>

                <div style={styles.actions}>

                  <button
                    style={styles.feature}
                    onClick={() =>
                      featurePost(p.id)
                    }
                  >
                    Feature
                  </button>

                  <button
                    style={styles.delete}
                    onClick={() =>
                      deletePost(p.id)
                    }
                  >
                    Delete
                  </button>

                </div>
              </div>
            ))}
          </div>
        )}

        {/* COMMENTS */}
        {tab === "comments" && (
          <div>

            {comments.map((c) => (

              <div
                key={c.id}
                style={styles.card}
              >

                <p>{c.content}</p>

                <div style={styles.actions}>

                  <button
                    style={styles.approve}
                    onClick={() =>
                      approveComment(c.id)
                    }
                  >
                    Approve
                  </button>

                  <button
                    style={styles.reject}
                    onClick={() =>
                      rejectComment(c.id)
                    }
                  >
                    Reject
                  </button>

                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}

const styles = {

  page: {
    background: "#0f172a",
    minHeight: "100vh",
    color: "white",
    padding: "30px",
  },

  heading: {
    marginBottom: "25px",
  },

  tabs: {
    display: "flex",
    gap: "15px",
    marginBottom: "30px",
  },

  tab: {
    padding: "10px 18px",
    border: "none",
    borderRadius: "8px",
    background: "#1e293b",
    color: "white",
    cursor: "pointer",
  },

  card: {
    background: "#1e293b",
    padding: "20px",
    borderRadius: "12px",
    marginBottom: "20px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },

  actions: {
    display: "flex",
    gap: "10px",
  },

  author: {
    background: "#38bdf8",
    border: "none",
    padding: "10px",
    borderRadius: "8px",
    color: "white",
    cursor: "pointer",
  },

  admin: {
    background: "#a855f7",
    border: "none",
    padding: "10px",
    borderRadius: "8px",
    color: "white",
    cursor: "pointer",
  },

  feature: {
    background: "#facc15",
    border: "none",
    padding: "10px",
    borderRadius: "8px",
    color: "#000",
    cursor: "pointer",
  },

  approve: {
    background: "#22c55e",
    border: "none",
    padding: "10px",
    borderRadius: "8px",
    color: "white",
    cursor: "pointer",
  },

  reject: {
    background: "#ef4444",
    border: "none",
    padding: "10px",
    borderRadius: "8px",
    color: "white",
    cursor: "pointer",
  },

  delete: {
    background: "#dc2626",
    border: "none",
    padding: "10px",
    borderRadius: "8px",
    color: "white",
    cursor: "pointer",
  },

  denied: {
    background: "#0f172a",
    minHeight: "100vh",
    color: "white",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    fontSize: "32px",
  },
};