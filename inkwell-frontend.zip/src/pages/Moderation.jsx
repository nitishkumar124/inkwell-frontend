import { useEffect, useState } from "react";

import API from "../api/api";

import Navbar from "../components/Navbar";

import { getRole } from "../auth/auth";

export default function Moderation() {

  const role = getRole();

  const [comments, setComments] = useState([]);

  // AUTHOR ONLY
  if (role !== "AUTHOR") {
    return (
      <>
        <Navbar />

        <div style={styles.denied}>
          Access Denied
        </div>
      </>
    );
  }

  // FETCH PENDING COMMENTS
  const fetchComments = async () => {

    try {

      const res = await API.get("/comments/pending");

      setComments(res.data.data);

    } catch (err) {

      console.error(err);
    }
  };

  // APPROVE
  const approveComment = async (id) => {

    try {

      await API.put(`/comments/${id}/approve`);

      fetchComments();

    } catch (err) {

      console.error(err);
    }
  };

  // REJECT
  const rejectComment = async (id) => {

    try {

      await API.put(`/comments/${id}/reject`);

      fetchComments();

    } catch (err) {

      console.error(err);
    }
  };

  useEffect(() => {

    fetchComments();

  }, []);

  return (
    <>
      <Navbar />

      <div style={styles.page}>

        <h1 style={styles.heading}>
          Comment Moderation
        </h1>

        {comments.length === 0 && (
          <div style={styles.empty}>
            No pending comments
          </div>
        )}

        <div style={styles.grid}>

          {comments.map((c) => (

            <div key={c.id} style={styles.card}>

              {/* POST */}
              <div style={styles.postTitle}>
                Post #{c.postId}
              </div>

              {/* STATUS */}
              <div style={styles.pending}>
                ⏳ Pending Approval
              </div>

              {/* CONTENT */}
              <p style={styles.content}>
                {c.content}
              </p>

              {/* ACTIONS */}
              <div style={styles.actions}>

                <button
                  style={styles.approve}
                  onClick={() =>
                    approveComment(c.id)
                  }
                >
                  Approve
                </button>

                <button
                  style={styles.reject}
                  onClick={() =>
                    rejectComment(c.id)
                  }
                >
                  Reject
                </button>

              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

const styles = {

  page: {
    background: "#0f172a",
    minHeight: "100vh",
    padding: "30px",
    color: "white",
  },

  heading: {
    marginBottom: "30px",
  },

  empty: {
    color: "#94a3b8",
    marginTop: "20px",
  },

  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))",
    gap: "25px",
  },

  card: {
    background: "#1e293b",
    padding: "20px",
    borderRadius: "14px",
    boxShadow: "0 6px 14px rgba(0,0,0,0.25)",
  },

  postTitle: {
    color: "#38bdf8",
    marginBottom: "10px",
    fontWeight: "bold",
  },

  pending: {
    color: "#facc15",
    marginBottom: "15px",
  },

  content: {
    color: "#e2e8f0",
    lineHeight: "1.6",
  },

  actions: {
    marginTop: "20px",
    display: "flex",
    gap: "10px",
  },

  approve: {
    flex: 1,
    padding: "10px",
    background: "#22c55e",
    border: "none",
    borderRadius: "8px",
    color: "white",
    cursor: "pointer",
  },

  reject: {
    flex: 1,
    padding: "10px",
    background: "#ef4444",
    border: "none",
    borderRadius: "8px",
    color: "white",
    cursor: "pointer",
  },

  denied: {
    background: "#0f172a",
    minHeight: "100vh",
    color: "white",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    fontSize: "32px",
  },
};